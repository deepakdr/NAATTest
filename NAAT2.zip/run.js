const LOTSIZE = 50;
var previousDayCandle = {};
const today = new Date();
var yesterday = new Date(today);
yesterday.setDate(yesterday.getDate() - 1);

var previousDayData;
var data; //! array to store the nifty index candles of today
var dataVix; //! array to store the india vix 
var lastProcessedIndex = -1; //! variable to figure out the last candle processed.
var daysData; //! current days data will be put here
var user_id = localStorage.getItem('__storejs_kite_user/user_id').replace(/"/g, '');
function start() {
    //! This will be the entry point for the program
    //! regardless of the time, there needs to be few housekeeping
    //! it needs to get the previous days data. 
    //! Note: if the previous day is holiday then it has keep traversing back until it gets data
    //! Build days empty days data and fill in the previous day close and open
    // var r = confirm("N.A.A.T: Do you want to override default target & stoploss?, if yes, press 'Ok'");
    // if (r == true) {
    //     var newTarget = parseInt(prompt('Enter Target Points:', '50'));
    //     var newStopLoss = parseInt(prompt('Enter Stoploss Points:', '50'));
    //     console.log(newTarget, newStopLoss);

    // }
    console.log('Starting N.A.A.T', new Date());
    getYesterdaysData();
    const greeting = new Notification('Initiating N.A.A.T, Aligning time...', {
        body: 'N.A.A.T is aligining with the seconds first',
        icon: 'https://deepakdr.github.io/images/bullRun.png'
    });
    setTimeout(() => {
        greeting.close();
    }, 3000);
    // fn15MinInterval();
    fnGetCEName(); fnGetPEName();

}
function getYesterdaysData() {
    const getPastDataURL = "https://kite.zerodha.com/oms/instruments/historical/256265/15minute?oi=1&from=" + formatDate(yesterday) + "&to=" + formatDate(yesterday);
    var req = new XMLHttpRequest();
    req.open("GET", getPastDataURL);
    req.setRequestHeader('authorization', "enctoken " + localStorage.getItem('__storejs_kite_enctoken').replace(/"/g, ''));
    req.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            var response = JSON.parse(req.responseText);
            if (response.data.candles.length === 0) {
                //>> this means the previous day was a holiday, so reduce the date and run this method again
                yesterday.setDate(yesterday.getDate() - 1);
                getYesterdaysData();

            }
            else {
                previousDayData = response.data;
                // previousDayCandle.open = response.data.candles[0][1];//>> the last record will contain the latest previous day record
                // previousDayCandle.close = response.data.candles[response.data.candles.length - 1][4];

                const getVixDataURL = "https://kite.zerodha.com/oms/instruments/historical/264969/15minute?oi=1&from=" + formatDate(yesterday) + "&to=" + formatDate(yesterday);
                var reqVix = new XMLHttpRequest();
                reqVix.open("GET", getVixDataURL);
                reqVix.setRequestHeader('authorization', "enctoken " + localStorage.getItem('__storejs_kite_enctoken').replace(/"/g, ''));
                reqVix.onreadystatechange = function () {
                    if (this.readyState == 4 && this.status == 200) {
                        var response = JSON.parse(reqVix.responseText);
                        dataVix = response.data;
                        runMain();
                    }
                }
                reqVix.send();
                //  runMain(); //>> once we have previous days data we can start checking for current days data
            }
        }
    }
    req.send();
}
function runMain() {
    //>> we got the previous days data, using the below iteration we build the days data for previous day
    //>> post which we will do a request for current day
    for (let index = 0; index < previousDayData.candles.length; index++) {
        fnProcessCore(previousDayData.candles[index], index);
    }
    //>> this will be the place where we will try to get current data 
    var intervalVar = setInterval(() => {
        var date = new Date(); // Create a Date object to find out what time it is
        if (date.getSeconds() === 0 ||
            date.getMinutes() === 0 ||
            date.getMinutes() === 15 ||
            date.getMinutes() === 30 ||
            date.getMinutes() === 45) { // Check the time
            console.log("Seconds is on the dot: ", date.getSeconds());
            clearInterval(intervalVar);
            fnMinInterval();
            // Do stuff
        }
        else {
            //console.log(date.getSeconds());
        }
    }, 1000);
    // w = new Worker("worker.js");
    // getTodaysNiftyData();
}
var minIntervalVar;
var currentMinute = 0, nextMinute = 0;
function fnMinInterval() {
    fnMinIntervalExtn();
    minIntervalVar = setInterval(() => {
        fnMinIntervalExtn();

    }, 1000);
}
var boolfnMinIntervalExtn = true;
function fnMinIntervalExtn() {
    var date = new Date();
    if (date.getMinutes() === 0 ||
        date.getMinutes() === 15 ||
        date.getMinutes() === 30 ||
        date.getMinutes() === 45) {
        console.log('Minutes: ', date.getMinutes());

        // currentMinute = date.getMinutes();
        // if (currentMinute + 15 === 60) nextMinute = 0;
        // else nextMinute = currentMinute + 15;

        console.log('Current Min:', currentMinute, 'Next Min:', nextMinute);

        if (date.getHours() === 9 && date.getMinutes() === 30) {
            if (boolfnMinIntervalExtn === true) {
                boolfnMinIntervalExtn = false;
                clearInterval(minIntervalVar);
                console.log("Retriving First Candle Data...");
                const greeting = new Notification('Retriving First Candle Data...', {
                    icon: 'https://deepakdr.github.io/images/bullRun.png',
                    body: 'N.A.A.T has started; getting 15 min candle data'
                });
                setTimeout(() => {
                    greeting.close();
                }, 3000);
                fn15MinInterval();
            }
        }
        else if (date.getHours() > 9 || (date.getHours() === 9 && date.getMinutes() >= 30)) {
            if (boolfnMinIntervalExtn === true) {
                boolfnMinIntervalExtn = false;
                clearInterval(minIntervalVar);
                console.log("Booting N.A.A.T, Market already open...", new Date());
                console.log("%c Noted: Program has been started after market open", 'color:red');
                const greeting = new Notification('Booting N.A.A.T, Entering already opened market...', {
                    body: 'N.A.A.T has started; getting 15 min candle data. Entering already opened market',
                    icon: 'https://deepakdr.github.io/images/bullRun.png'
                });
                setTimeout(() => {
                    greeting.close();
                }, 3000);

                fn15MinInterval();
            }

        }


    }
    else {
        //console.log("Minutes: ", date.getMinutes());
    }
}
var fifteenMinIntervalVar;

function fn15MinInterval() {
    //console.log('15 mins Interval');
    fn15MinIntervalExtn();
    fifteenMinIntervalVar = setInterval(() => {
        fn15MinIntervalExtn();
    }, 1000);

}
function fn15MinIntervalExtn() {
    var date = new Date();
    //console.log('15 mins Interval', date.getMinutes(), date.getSeconds());
    if (date.getMinutes() === nextMinute || (currentMinute === 0 && nextMinute === 0)
    ) {
        currentMinute = date.getMinutes();
        if (currentMinute + 15 === 60) nextMinute = 0;
        else nextMinute = currentMinute + 15;
        //>> this is the place we need to get nifty data for today
        console.log('Retriving Nifty Data For', new Date());
        getTodaysNiftyData();
    }
}
function getTodaysNiftyData() {
    //>> this method will be called every 15 mins to get the latest data of nifty 
    const getNiftyDataURL = "https://kite.zerodha.com/oms/instruments/historical/256265/15minute?oi=1&from=" + formatDate(today) + "&to=" + formatDate(today);
    var req = new XMLHttpRequest();
    req.open("GET", getNiftyDataURL);
    req.setRequestHeader('authorization', "enctoken " + localStorage.getItem('__storejs_kite_enctoken').replace(/"/g, ''));
    req.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            var response = JSON.parse(req.responseText);
            data = response.data;
            console.log('Got the NIFTY data', data);
            console.log('Retriving Nifty VIX Data For', new Date());

            getTodaysIndiaVixData();
        }
    }
    req.send();
}

function getTodaysIndiaVixData() {
    //>> this method will be called every 15 mins to get the latest data of nifty 
    const getVixDataURL = "https://kite.zerodha.com/oms/instruments/historical/264969/15minute?oi=1&from=" + formatDate(today) + "&to=" + formatDate(today);
    var req = new XMLHttpRequest();
    req.open("GET", getVixDataURL);
    req.setRequestHeader('authorization', "enctoken " + localStorage.getItem('__storejs_kite_enctoken').replace(/"/g, ''));
    req.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            var response = JSON.parse(req.responseText);
            dataVix = response.data; //! I am mindful and overridding the dataVix of previous day on purpose as we no longer require it
            console.log('Got the NIFTY VIX data', dataVix);

            fnProcess();
        }
    }
    req.send();
}
function fnProcess() {
    //! this is the place where both the back testing and live run converge
    //! fnProcessCore is shared by both back test and live test
    //! The program does need to handle scenarios where it was started after market open
    //! TODO: I WILL HAVE TO IMPLEMENT CODE FOR A DELAYED START
    //! fnProcess will be called every 15 minutes, however if the lastProcessedIndex and candle length does not match..
    //! ..it means we did not get the latest data for some reason
    if (lastProcessedIndex === -1 && data.candles.length === 1) {
        //>> this is the first candle received
        lastProcessedIndex++;
        console.log('fnProcess: Processing First Candle', new Date());

        fnProcessCore(data.candles[lastProcessedIndex], lastProcessedIndex);
    }
    else if (lastProcessedIndex === -1 && data.candles.length > 1) {
        //>> this means that we have more candles indicating the program was started after the window
        //>> we need to process the previous candles data
        console.log('Number of candles available: ', data.candles.length);
        lastProcessedIndex = data.candles.length;
        lastProcessedIndex = lastProcessedIndex - 1;
        for (let index = 0; index < data.candles.length - 1; index++) {
            PROCESSINGPREVIOUSDATA = true;
            console.log('fnProcess: Processing Previous Candles', new Date());

            fnProcessCore(data.candles[index], index);
        }
        PROCESSINGPREVIOUSDATA = false;
        console.log('fnProcess: Processed Previous Candles & processing current candle', new Date());

        fnProcessCore(data.candles[lastProcessedIndex], lastProcessedIndex);
        console.log(data.candles[lastProcessedIndex], lastProcessedIndex);
    }
    else if (lastProcessedIndex != -1 && lastProcessedIndex > data.candles.length - 1) {
        //>> this means we got the latest candle so we can process the latest candle.
        lastProcessedIndex++;
        console.log('fnProcess: Processing latest Candle', new Date());
        fnProcessCore(data.candles[lastProcessedIndex], lastProcessedIndex);
    }
    else if (lastProcessedIndex != -1 && lastProcessedIndex === data.candles.length - 1) {
        //>> this means that while the function was triggerred we did not get the latest candle data, this could be 
        //>> because of any issue with the api call or kite not getting overloaded
        //>> in such case re-issue the request again
        console.log('%c THE DATA RECEIVED DOES NOT CONTAIN THE LATEST CANDLE, RE-ISSUING', 'color:red;background-color:white');
        getTodaysNiftyData();
    }

}
function fnGetPEName() {
    var pe, x = null;
    for (const a of document.querySelectorAll("span")) {
        if (a.textContent.includes("PE")) {
            x = a; break;
        }
    }
    if (x === null) {
        console.error("NO PE SCRIPT AVAILABLE IN WATCHLIST!");
        const error = new Notification('ERROR: NO PUT SCRIPT AVAILABLE IN WATCHLIST!', {
            body: 'Please check your watch list',
            icon: 'https://deepakdr.github.io/images/bullRun.png'
        });
        return;

    }
    var y = x.children[0].children[0].textContent.split(" ");
    if (y.length === 4) {
        var yr = new Date().getFullYear().toString().substr(2, 2);
        pe = y[0] + yr + y[1] + y[2] + y[3];
        console.log("Monthly Expiry Available:", pe);
    }
    else if (y.length === 6) {
        var m = parseInt(y[1]).toString();
        if (m.length === 1) m = "0" + m;
        var yr = new Date().getFullYear().toString().substr(2, 2);
        pe = y[0] + yr + y[3].substr(0, 1) + m + y[4] + y[5];
    }
    else {
        console.error("UNABLE TO DETERMINE PUT SCRIP NAME!");
        const error = new Notification('ERROR: UNABLE TO DETERMINE PUT SCRIP NAME!', {
            body: 'Please check your watch list',
            icon: 'https://deepakdr.github.io/images/bullRun.png'
        });
    }
    console.log('PUT Script considered:', pe);
    const callMsg = new Notification('PUT SCRIPT: ' + pe, {
        body: 'PUT Script Considered: ' + x.children[0].children[0].textContent + ' ' + pe,
        icon: 'https://deepakdr.github.io/images/bullRun.png'
    });
    setTimeout(() => {
        callMsg.close();
    }, 2000);
    if (pe.length != 17) {
        console.error("PUT SCRIPT DOES NOT MEET THE LENGTH CONDITION");
        const error = new Notification('ERROR: PUT SCRIPT DOES NOT MEET THE LENGTH CONDITION!', {
            body: 'Please check your watch list',
            icon: 'https://deepakdr.github.io/images/bullRun.png'
        });
        return;
    }
    return pe;
}

function fnGetCEName() {
    var ce, x = null;
    for (const a of document.querySelectorAll("span")) {
        if (a.textContent.includes("CE")) {
            x = a; break;
        }
    }
    if (x === null) {
        console.error("NO CE SCRIPT AVAILABLE IN WATCHLIST!");
        const error = new Notification('ERROR: NO CALL SCRIPT AVAILABLE IN WATCHLIST!', {
            body: 'Please check your watch list',
            icon: 'https://deepakdr.github.io/images/bullRun.png'
        });
        return;

    }
    var y = x.children[0].children[0].textContent.split(" ");
    if (y.length === 4) {
        var yr = new Date().getFullYear().toString().substr(2, 2);
        ce = y[0] + yr + y[1] + y[2] + y[3];
        console.log("Monthly Expiry Available:", ce);
    }
    else if (y.length === 6) {
        var m = parseInt(y[1]).toString();
        if (m.length === 1) m = "0" + m;
        var yr = new Date().getFullYear().toString().substr(2, 2);
        ce = y[0] + yr + y[3].substr(0, 1) + m + y[4] + y[5];
    }
    else {
        console.error("UNABLE TO DETERMINE CALL SCRIP NAME!");
        const error = new Notification('ERROR: UNABLE TO DETERMINE CALL SCRIP NAME!', {
            body: 'Please check your watch list',
            icon: 'https://deepakdr.github.io/images/bullRun.png'
        });
    }
    console.log('CALL Script considered:', ce);
    const callMsg = new Notification('CALL SCRIPT: ' + ce, {
        body: 'Call Script Considered: ' + x.children[0].children[0].textContent + ' ' + ce,
        icon: 'https://deepakdr.github.io/images/bullRun.png'
    });
    setTimeout(() => {
        callMsg.close();
    }, 2000);
    if (ce.length != 17) {
        console.error("CALL SCRIPT DOES NOT MEET THE LENGTH CONDITION");
        const error = new Notification('ERROR: CALL SCRIPT DOES NOT MEET THE LENGTH CONDITION!', {
            body: 'Please check your watch list',
            icon: 'https://deepakdr.github.io/images/bullRun.png'
        });
        return;
    }
    return ce;
}
function formatDate(dt) {
    var day = dt.getDate() + "";
    if (day.length === 1) {
        day = "0" + day;
    }
    var mon = dt.getMonth() + 1;
    mon = mon + "";
    if (mon.length === 1) {
        mon = "0" + mon;
    }
    var year = dt.getFullYear() + "";
    var dtval = year + "-" + mon + "-" + day;
    return dtval;
}

var ceScriptBought = "";
function fnBuyCall() {
    var ce = fnGetCEName();
    ceScriptBought = ce;
    fnBuildOptionData(ce, 'BUY', LOTSIZE);
}


function fnSellCall() {
    if (ceScriptBought != "") {
        fnBuildOptionData(ceScriptBought, 'SELL', LOTSIZE);
        ceScriptBought = "";
    }
    else {
        console.error('EXIT MANUALLY! - Unable to figure out the CE that was bought');
        const error = new Notification('EXIT MANUALLY! - Unable to figure out the CE that was bought', {
            body: 'ceScriptBought does not contain value!',
            icon: 'https://deepakdr.github.io/images/bullRun.png'
        });
    }

}



var peScriptBought = "";
function fnBuyPut() {
    var pe = fnGetPEName();
    peScriptBought = pe;
    fnBuildOptionData(pe, 'BUY', LOTSIZE);
}


function fnSellPut() {
    if (peScriptBought != "") {
        fnBuildOptionData(peScriptBought, 'SELL', LOTSIZE);
        peScriptBought = "";
    }
    else {
        console.error('EXIT MANUALLY! - Unable to figure out the PE that was bought');
        const error = new Notification('EXIT MANUALLY! - Unable to figure out the PE that was bought', {
            body: 'peScriptBought does not contain value!',
            icon: 'https://deepakdr.github.io/images/bullRun.png'
        });
    }

}


function fnBuildOptionData(scriptName, BUYSELL, lotSize) {
    if (typeof (scriptName) === "undefined" || scriptName === null || scriptName === "") {
        console.error('Error: Script Name not passed');
        const error = new Notification('ERROR: Script Name Not Passed!', {
            body: 'Order will not be placed',
            icon: 'https://deepakdr.github.io/images/bullRun.png'
        });
        return;
    }

    if (typeof (BUYSELL) === "undefined" || BUYSELL === null) {
        console.error('Error: BUY or SELL not passed');
        const error = new Notification('ERROR: BUY OR SELL Parameter Not Passed!', {
            body: 'Order will not be placed',
            icon: 'https://deepakdr.github.io/images/bullRun.png'
        });
        return;
    }

    if (typeof (lotSize) === 'undefined' || lotSize === 0 || lotSize === null) {
        console.warn('N.A.A.T: Lot Size not passed setting to default value of 50');
        lotSize = 50;
    }
    var data = {
        variety: 'regular',
        exchange: 'NFO',
        tradingsymbol: scriptName,
        transaction_type: BUYSELL,
        order_type: 'MARKET',
        quantity: lotSize, //lot size is 1 here
        price: 0,
        product: 'MIS',
        validity: 'DAY',
        disclosed_quantity: 0,
        trigger_price: 0,
        squareoff: 0,
        stoploss: 0,
        trailing_stoploss: 0,
        user_id: user_id
    }

    var msg = 'Order for ' + BUYSELL + ' ' + scriptName + ' Q: ' + lotSize + ' Placed!';
    console.log(msg, data);
    var icon = 'https://deepakdr.github.io/images/bullRun.png';
    if (BUYSELL === "BUY" && scriptName.toString().indexOf("CE") > -1) {
        icon = "https://deepakdr.github.io/images/buycall.png";
    }
    else if (BUYSELL === "BUY" && scriptName.toString().indexOf("PE") > -1) {
        icon = "https://deepakdr.github.io/images/buyput.png";
    }
    else if (BUYSELL === "SELL" && scriptName.toString().indexOf("CE") > -1) {
        icon = "https://deepakdr.github.io/images/sellcall.png";
    }
    else if (BUYSELL === "SELL" && scriptName.toString().indexOf("PE") > -1) {
        icon = "https://deepakdr.github.io/images/sellput.png";
    }
    const placingOrderMsg = new Notification(msg, {
        icon: icon
    });

    // if (canPlaceIndexOrder === true && new Date() >= tradeTime && new Date() <= tradeEndTime) {
    var oReq = new XMLHttpRequest();
    oReq.open("POST", "https://kite.zerodha.com/oms/orders/regular");
    oReq.onreadystatechange = function () {
        if (this.readyState == 4) {
            // Typical action to be performed when the document is ready:
            var obj = JSON.parse(oReq.responseText);

            const orderPlacedMsg = new Notification('Response: ' + obj.status.toString().toUpperCase(), {
                body: 'Response Text: ' + oReq.responseText,
                icon: 'https://deepakdr.github.io/images/bullRun.png'
            });
            console.log('ORDER PLACED, response:', obj);

        }
    }
    //oReq.setRequestHeader("authorization", "enctoken " + public_token);
    oReq.setRequestHeader("authorization", "enctoken " + localStorage.getItem('__storejs_kite_enctoken').replace(/"/g, ''));
    oReq.setRequestHeader("x-kite-userid", user_id);
    oReq.setRequestHeader("x-kite-version", '2.1.0');
    oReq.setRequestHeader("content-type", 'application/x-www-form-urlencoded');

    var urlEncodedDataPairs = [];

    for (name in data) {
        urlEncodedDataPairs.push(encodeURIComponent(name) + '=' + encodeURIComponent(data[name]));
    }
    var urlEncodedData = urlEncodedDataPairs.join('&').replace(/%20/g, '+');
    oReq.send(urlEncodedData);
    //}
}
start();