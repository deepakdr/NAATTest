var daysData;
var PROCESSINGPREVIOUSDATA = false;
var boolfnBearPatternAfterGapDown = true,
    boolfnSignificantGapDuringOpen = true,
    boolfnBullOpenBreaksFirstSupport = true,
    boolfnBearOpenBreaksFirstResistance = true,
    boolfnThreeGreenCandles = true,
    boolfnThreeRedCandles = true,
    boolfnGapUpAndFirst3CandlesNegative = true,
    boolfnGapDownOpenAndBullTrendReversal = true,
    boolfnGapUpOpenAndBearTrendReversal = true,
    boolfnGapUpOpenAndHighActsResistance = true;

var continueTradeOverride = false, testMode = false;
var entry, entryAtIndex = 0, target, stopLoss, targetMoved = false, totalTradePointsProfit = 0, totalTradePointsLoss = 0, staleTradeCounter = 0;
var day = -1, indx = 0, profitCounter = 0, lossCounter = 0, isTrading = false, longShort = 0;
var daysTradePointsProfit = 0, daysTradePointsLoss = 0;
var entryPercentage, entry, entryNearRange, entryWhenAtRangeOf, entryMinute,
    entryDistanceFromLow, entryDistanceFromHigh, entryAvgCloseDistanceFromLow, entryAvgCloseDistanceFromHigh,
    entryDiffOpenEntry, entryDiffOpenAvgCloseOnEntry, entryDiffYstdyCloseAndEntry,
    entryStrikeToBreakCounter = 0, entryStrikeBrokenCounter = 0;
var arrProfitDayRange = [], arrLossDayRange = [], arrProfitMin = [], arrLossMin = [], arrProfitPercent = [], arrLossPercent = [], arrCandleObj = [], arrProfitRangePercent = [], arrLossRangePercent = [], arrdaysData = [];
var indicatorsArray = [];


var ALERTCLOSEOPENTRADES = false, ALERTTRADEWINDOWCLOSED = false;
var STOPLOSSTICK = 50, TARGETTICK = 50;
var disableAfterTwoTrades = true, reverseTrade = false;
var movingTargetPoints = 5, moveTargetAtDiff = 50;


function fnCandleObj(o, h, l, c, dtTime, vix) {
    this.open = o;
    this.high = h;
    this.low = l;
    this.close = c;
    this.dtTime = dtTime;
    this.percentageChange = ((c - o) / c) * 100;
    this.IndiaVix = vix;
}
function fnDaysData(o, h, l, c, d, date) {
    this.open = o;
    this.date = date;
    this.day = d;
    this.daysLow = l;
    this.daysHigh = h;
    this.dayAvgClose = c;
    this.dayTotalClose = c;
    this.lastClose = c;
    this.indx = 0;
    this.previousClose = 0;
    this.firstCandleClose = 0;
    this.firstTrade = 'NOTRADE';
    this.secondTrade = 'NOTRADE';
    this.brokenPreviousCloseSupportCount = 0;
    this.brokenPreviousCloseResistanceCount = 0;
    this.hasProfited = false;
    this.OpenTrend = null;
    this.firstResistance = 0;
    this.secondResistance = 0;
    this.firstSupport = 0;
    this.secondSupport = 0;
    this.firstResistanceBrokenCounter = 0;
    this.aboveFirstResistanceCounter = 0;
    this.secondResistanceBrokenCounter = 0;
    this.firstSupportBrokenCounter = 0;
    this.belowFirstSupportCounter = 0;
    this.secondSupportBrokenCounter = 0;
    this.belowSecondSupportCounter = 0;
    this.abovesecondResistanceCounter = 0;
    this.previousOpen = 0;
    this.previousDayChangePercent = 0;
    this.previousDayWas = '';
}
function fnProcessCore(candleElement, index) {
    // console.log('Entering Core...');
    const element = candleElement
    var candleObj = new fnCandleObj(parseFloat(element[1]), parseFloat(element[2]), parseFloat(element[3]), parseFloat(element[4]), element[0], dataVix.candles[index][4]);
    var dt = new Date(candleObj.dtTime);
    indicatorsArray.push({ c: candleObj.close });
    // tw.rsi(indicatorsArray, 14);
    // tw.ema(indicatorsArray, 20, 'c');
    if (dataVix.candles[index][4] > 30) {
        movingTargetPoints = 20, moveTargetAtDiff = 50;
        STOPLOSSTICK = 150, TARGETTICK = 150;
    }
    else if (dataVix.candles[index][4] > 20) {
        movingTargetPoints = 10, moveTargetAtDiff = 15;
        STOPLOSSTICK = 50, TARGETTICK = 50;
    }
    else {
        movingTargetPoints = 5, moveTargetAtDiff = 10;
        STOPLOSSTICK = 50, TARGETTICK = 50;
    }

    if ((dt.getHours() === 9 || dt.getHours() === 18) && dt.getMinutes() === 15) {
        day++;
        daysTradePointsProfit = 0;
        daysTradePointsLoss = 0;
        var daysData;
        if (candleObj.open > candleObj.close) {
            daysData = new fnDaysData(candleObj.open, candleObj.open, candleObj.close, candleObj.close, day, dt.toDateString());
        }
        else {
            daysData = new fnDaysData(candleObj.open, candleObj.close, candleObj.open, candleObj.close, day, dt.toDateString());

        }
        daysData.indx = 0;
        daysData.firstCandleClose = candleObj.close;

        if (day > 0) {
            daysData.previousClose = (arrdaysData[arrdaysData.length - 1]).lastClose;
            daysData.previousOpen = (arrdaysData[arrdaysData.length - 1]).open;
            if (daysData.previousClose > daysData.previousOpen) {
                daysData.previousDayChangePercent = ((daysData.previousClose - daysData.previousOpen) / daysData.previousOpen) * 100;
                daysData.previousDayWas = "POSITIVE";
                //console.log('Previous Days was Positive', daysData.previousOpen, daysData.previousClose, daysData.previousDayChangePercent);
            }
            else {
                daysData.previousDayChangePercent = ((daysData.previousOpen - daysData.previousClose) / daysData.previousClose) * 100;
                daysData.previousDayWas = "NEGATIVE";
                //console.log('Previous Days was NEGATIVE', daysData.previousOpen, daysData.previousClose, daysData.previousDayChangePercent);

            }


        }
        arrdaysData.push(daysData);
    }

    else {
        if (dt.getHours() === 15 && dt.getMinutes() === 0) {
            if (isTrading === true) {
                console.log('%c Time is 19:00; Squaring off the open positions!', 'background-color:white;font-weight:bold;color:purple');
                ALERTCLOSEOPENTRADES = true;
                if (longShort === 0) {
                    fnSellCall();
                    if (candleObj.close > entry) {
                        fnProfit(candleObj.dtTime, Math.round(candleObj.close - entry));
                        isTrading = false;
                        longShort = 0;
                    } else {
                        fnLoss(candleObj.dtTime, Math.round(entry - candleObj.close));
                        isTrading = false;
                        longShort = 0;
                    }
                }
                if (longShort === 1) {
                    fnSellPut();
                    if (candleObj.close >= entry) {
                        fnLoss(candleObj.dtTime, Math.round(candleObj.close - entry));
                        isTrading = false;
                        longShort = 0;

                    } else {
                        fnProfit(candleObj.dtTime, Math.round(entry - candleObj.close));
                        isTrading = false;
                        longShort = 0;
                    }
                }

            }
        }
        var daysData = arrdaysData[day];
        daysData.indx++;


        if (candleObj.open > candleObj.close) {
            if (candleObj.open > daysData.daysHigh) {
                daysData.daysHigh = candleObj.open;
            }
            if (candleObj.close < daysData.daysLow) {
                daysData.daysLow = candleObj.close;
            }
        } else {
            if (candleObj.close > daysData.daysHigh) {
                daysData.daysHigh = candleObj.open;
            }
            if (candleObj.open < daysData.daysLow) {
                daysData.daysLow = candleObj.open;
            }
        }

        daysData.dayTotalClose = (daysData.dayTotalClose + candleObj.close);
        daysData.dayAvgClose = daysData.dayTotalClose / (daysData.indx + 1);
        daysData.lastClose = candleObj.close;
        if (candleObj.open < daysData.previousClose && candleObj.close < daysData.previousClose && daysData.firstCandleClose > daysData.previousClose) {
            daysData.brokenPreviousCloseSupportCount++;
        }
        if (candleObj.open > daysData.previousClose && candleObj.close > daysData.previousClose && daysData.firstCandleClose < daysData.previousClose) {
            daysData.brokenPreviousCloseResistanceCount++;
        }
        var differenceBetweenFirstCurrentClose = parseFloat(candleObj.close - daysData.firstCandleClose).toFixed(2);
        if (daysData.arrDifferenceOfClose) {
            daysData.arrDifferenceOfClose.push(differenceBetweenFirstCurrentClose);
        }
        else {
            daysData.arrDifferenceOfClose = [];
            daysData.arrDifferenceOfClose.push(differenceBetweenFirstCurrentClose);
        }

    }
    arrCandleObj.push(candleObj);
    if (day === 0) {
        //console.log('skipping as day is 0');
    }
    else {
        if (isTrading === true) {
            if (longShort === 0) {

                if (candleObj.high >= target) {
                    fnSellCall();
                    fnProfit(candleObj.dtTime, Math.round(candleObj.high - entry));
                    isTrading = false;
                    longShort = 0;
                }
                if (candleObj.high > stopLoss && stopLoss >= entry) {
                    fnSellCall();
                    console.log('%c Stop Loss Hit, but Profit', 'color:white;background-color:blue');
                    fnProfit(candleObj.dtTime, Math.round(candleObj.high - entry));
                    isTrading = false;
                    longShort = 0;
                }
                if (candleObj.low <= stopLoss && stopLoss < entry) {
                    fnSellCall();
                    fnLoss(candleObj.dtTime, Math.round(entry - candleObj.low));
                    isTrading = false;
                    longShort = 0;
                    if (fnCheckCurrentDayBeforeEntry()) {
                        if (reverseTrade === true)
                            fnEnterShort(candleObj, 'Call failed, Buying Put');
                    }

                }
                else {
                    if ((Math.round((target - candleObj.high) > 0) && Math.round((target - candleObj.high)) < moveTargetAtDiff)) {
                        console.log('Nearing Current Target, Updating Target by 5 points');
                        target = target + movingTargetPoints;
                        stopLoss = stopLoss + movingTargetPoints;
                        console.debug('LONG: Moving the target', candleObj.dtTime, Math.round(target - candleObj.high - movingTargetPoints), 'Current Target:', candleObj.high, target - movingTargetPoints, 'New Target:', target);

                    }
                }

            }
            if (longShort === 1) {

                if (candleObj.low <= target) {
                    fnSellPut();
                    fnProfit(candleObj.dtTime, Math.round(entry - candleObj.low));
                    isTrading = false;
                    longShort = 0;
                }
                if (candleObj.low <= stopLoss && stopLoss <= entry) {
                    console.log('%c Stop Loss Hit, but Profit', 'color:white;background-color:blue');
                    fnSellPut();

                    fnProfit(candleObj.dtTime, Math.round(entry - candleObj.low));
                    isTrading = false;
                    longShort = 0;
                }
                if (candleObj.high >= stopLoss && stopLoss > entry) {
                    fnSellPut();

                    fnLoss(candleObj.dtTime, Math.round(candleObj.high - entry));
                    isTrading = false;
                    longShort = 0;
                    if (fnCheckCurrentDayBeforeEntry()) {
                        if (reverseTrade === true)
                            fnEnterLong(candleObj, 'Put failed, Buying Call');
                    }
                }
                else {
                    if (Math.round((candleObj.low - target)) > 0 && Math.round((candleObj.low - target)) < moveTargetAtDiff) {
                        console.log('Nearing Current Target, Updating Target by 5 points');
                        target = target - movingTargetPoints;
                        stopLoss = stopLoss - movingTargetPoints;
                        console.debug('SHORT: Moving the target', candleObj.dtTime, Math.round(candleObj.low - target - movingTargetPoints), candleObj.low, 'Current Target:', target - movingTargetPoints, 'New Target:', target);

                    }
                }

            }

        }


        if (daysData.indx === 0 && daysData.previousClose > daysData.open
        ) {
            // fnPrintVerbose(candleObj.dtTime + 'Day has opened negative, the first resistance will be the open & second will be previous day close');
            daysData.OpenTrend = 'NEGATIVE';
            daysData.firstResistance = candleObj.open;
            daysData.secondResistance = daysData.previousClose;
        }
        if (daysData.OpenTrend === 'NEGATIVE'
        ) {
            if (candleObj.open > daysData.firstResistance && candleObj.close > daysData.firstResistance) daysData.aboveFirstResistanceCounter++;
            if (candleObj.open < daysData.firstResistance && candleObj.close > daysData.firstResistance) daysData.firstResistanceBrokenCounter++;
            if (candleObj.open < daysData.secondResistance && candleObj.close > daysData.secondResistance) daysData.secondResistanceBrokenCounter++;
            if (candleObj.open > daysData.secondResistance && candleObj.close > daysData.secondResistance) daysData.abovesecondResistanceCounter++;

        }

        if (daysData.indx === 0 && daysData.open > daysData.previousClose

        ) {
            //  fnPrintVerbose(candleObj.dtTime + 'Day has opened POSITIVE, the first SUPPORT will be the open & second will be previous day close');
            daysData.OpenTrend = 'POSITIVE';
            daysData.firstSupport = candleObj.open;
            daysData.secondSupport = daysData.previousClose;
        }
        if (daysData.OpenTrend === 'POSITIVE'

        ) {
            if (candleObj.open < daysData.firstSupport && candleObj.close < daysData.firstSupport) daysData.belowFirstSupportCounter++;
            if (candleObj.close < daysData.firstSupport && candleObj.open > daysData.firstSupport) daysData.firstSupportBrokenCounter++;
            if (candleObj.open < daysData.secondSupport && candleObj.close < daysData.secondSupport) daysData.belowSecondSupportCounter++;
            if (candleObj.open > daysData.secondSupport && candleObj.close < daysData.secondSupport) daysData.secondSupportBrokenCounter++;

        }


        if (fnCheckCurrentDayBeforeEntry()) {
            if (dt.getHours() === 15) {
                if (dt.getMinutes() >= 0) {
                    console.log('Trade Window Ended');
                    //console.log(dt, daysData.daysHigh, daysData.daysLow);
                    ALERTTRADEWINDOWCLOSED = true;
                    //  continue;
                }
            }
            else if (dt.getHours() >= 15) {
                // continue;
            }
            else {

                if (index > 15) {
                    //consider RSI;
                    //fnCheckRSILevel();
                }

                // //fnGapDownOpenAndLowActsSupport();
                // // fnBullPatternAfterGapUp();
                if (PROCESSINGPREVIOUSDATA === false) {
                    console.log('Checking Patterns...');

                    fnBearPatternAfterGapDown();
                    fnSignificantGapDuringOpen();
                    fnBullOpenBreaksFirstSupport();
                    fnBearOpenBreaksFirstResistance();
                    fnThreeGreenCandles();
                    fnThreeRedCandles();
                    fnGapUpAndFirst3CandlesNegative();
                    fnGapDownOpenAndBullTrendReversal();
                    fnGapUpOpenAndBearTrendReversal();
                    fnGapUpOpenAndHighActsResistance();
                }
            }

        }
    }
}


function fnBearPatternAfterGapDown() {
    if (boolfnBearPatternAfterGapDown === false)
        return;

    var daysData = arrdaysData[day];
    var candleObj = arrCandleObj[arrCandleObj.length - 1];

    if (daysData.indx > 0) {
        return;
    }

    if ((candleObj.close - daysData.previousClose) >= 90 && (candleObj.close < candleObj.open) && (candleObj.open - candleObj.close) > 10) {
        fnPrintVerbose('Gap down of 90 points, indicates a bear sentiment, Buy Put');
        fnEnterShort(candleObj, 'fnBearPatternAfterGapDown');
    }
}

function fnGapUpOpenAndHighActsResistance() {
    if (boolfnGapUpOpenAndHighActsResistance === false) return;
    var daysData = arrdaysData[day];
    if (daysData.indx < 2) {
        return;
    }
    var candleObj = arrCandleObj[arrCandleObj.length - 1];
    var candleObj2 = arrCandleObj[arrCandleObj.length - 2];

    if ((daysData.open - daysData.previousClose) > 0) {
        //if the day opened with gap up and the previous candle close is the days high
        // and if the current candle open is around the same spot and is red
        //probability the market will go reverse provided there is some distance to trade b/w 
        //current point and the open
        if (candleObj.open > candleObj.close && Math.abs((candleObj.open - daysData.daysHigh)) < 5
            && candleObj2.close === daysData.daysHigh && daysData.open < candleObj.close
            && candleObj.close - daysData.open > 10) {
            fnEnterShort(candleObj, 'fnGapUpOpenAndHighActsResistance');
        }
    }
}

function fnGapUpOpenAndBearTrendReversal() {
    if (boolfnGapUpOpenAndBearTrendReversal === false) return;
    var daysData = arrdaysData[day];
    var candleObj = arrCandleObj[arrCandleObj.length - 1];
    var candleObj2 = arrCandleObj[arrCandleObj.length - 2];
    if (candleObj.close > candleObj.open
        && Math.abs(candleObj.open - daysData.previousClose) < 5
        && candleObj2.open > candleObj2.close
        && Math.abs(candleObj2.close - daysData.previousClose) < 5
        && daysData.secondSupportBrokenCounter === 0
        && daysData.belowSecondSupportCounter === 0
        && daysData.OpenTrend === "POSITIVE") {
        fnEnterLong(candleObj, 'fnGapUpOpenAndBearTrendReversal');
    }
}

function fnGapDownOpenAndBullTrendReversal() {
    if (boolfnGapDownOpenAndBullTrendReversal === false) return;
    /**
     * ! Trend reversal 
     * * The day opens with a considerable gap down. 
     * * The current candle is opening closer to the previous day close and closes in red
     * * The previous candle is green and closes near the previous day close
     * * And the last 2 candles are also in green
     * * And there was no instance where the previous day close was broken
     * * this indicates a trend reversal
     */
    var daysData = arrdaysData[day];
    var candleObj = arrCandleObj[arrCandleObj.length - 1];
    var candleObj2 = arrCandleObj[arrCandleObj.length - 2];
    if (candleObj.open > candleObj.close
        && Math.abs(candleObj.open - daysData.previousClose) < 5
        && candleObj2.close > candleObj2.open
        && Math.abs(candleObj2.close - daysData.previousClose) < 5
        && daysData.secondResistanceBrokenCounter === 0
        && daysData.abovesecondResistanceCounter === 0
        && daysData.OpenTrend === 'NEGATIVE'
    ) {
        fnEnterShort(candleObj, 'fnGapDownOpenAndBullTrendReversal');
    }

}
function fnGapUpAndFirst3CandlesNegative() {
    if (boolfnGapUpAndFirst3CandlesNegative === false) return;

    var daysData = arrdaysData[day];
    var candleObj = arrCandleObj[arrCandleObj.length - 1];
    var candleObj2 = arrCandleObj[arrCandleObj.length - 2];
    var candleObj3 = arrCandleObj[arrCandleObj.length - 3];

    if (daysData.open - daysData.previousClose > 0
        && candleObj.open - candleObj.close > 0
        && candleObj2.open - candleObj2.close > 0
        && candleObj3.open - candleObj3.close > 0
        && candleObj.close - daysData.previousClose > TARGETTICK
        && daysData.indx >= 2 && daysData.indx < 10) {
        fnEnterShort(candleObj, 'fnGapUpAndFirst3CandlesNegative: Gap Up Openening, but three candles are in red and there is room for target and this between candle index >=2 & <10');
    }

}

function fnThreeGreenCandles() {
    if (boolfnThreeGreenCandles === false) return;

    var daysData = arrdaysData[day];
    var candleObj = arrCandleObj[arrCandleObj.length - 1];
    var candleObj2 = arrCandleObj[arrCandleObj.length - 2];
    var candleObj3 = arrCandleObj[arrCandleObj.length - 3];

    /**
    * ! If 3 Candles are GREEN.
    * ! And the difference b/w the latest candle close and t-2 candle open is greater than 0
    * ! And the day does not have a huge gap up opening and it was b/w 0 and 80
    * ! And MOST IMPORTANT the candle is currently below the days open.
    * * In plain english - if the 3 candles are in green and the day did have a positive opening
    * * and then the current candle is below the days open then we trade.
    * * The rational is - in case if the day had positive opening compared to previous close, and if the current candle is below the days open, then there is probability 
    * * that it will go up
    */
    if (candleObj.close > candleObj.open
        && candleObj2.close > candleObj2.open
        && candleObj3.close > candleObj3.open
        && daysData.indx >= 2
        && candleObj.close - candleObj3.open > 0
        && daysData.open - daysData.previousClose > 0
        && candleObj.close < daysData.open
    ) {
        fnEnterLong(candleObj, 'fnThreeGreenCandles: Three green candles are formed & trend continues; indicating bull pattern');
    }


}
function fnThreeRedCandles() {
    if (boolfnThreeRedCandles === false) return;

    var daysData = arrdaysData[day];
    var candleObj = arrCandleObj[arrCandleObj.length - 1];
    var candleObj2 = arrCandleObj[arrCandleObj.length - 2];
    var candleObj3 = arrCandleObj[arrCandleObj.length - 3];
    if (candleObj.close < candleObj.open
        && candleObj2.close < candleObj2.open
        && candleObj3.close < candleObj3.open
        && daysData.indx >= 2
        && candleObj3.open - candleObj.close > 0
    ) {

        fnEnterShort(candleObj, 'fnThreeRedCandles: Three red candles are formed & trend continues; indicating bear pattern');
    }
}

function fnBullOpenBreaksFirstSupport(daysData, candleObj) {
    if (boolfnBullOpenBreaksFirstSupport === false)
        return;
    var daysData = arrdaysData[day];
    var candleObj = arrCandleObj[arrCandleObj.length - 1];
    if (daysData.OpenTrend === 'POSITIVE' && candleObj.open < daysData.firstSupport && candleObj.close < daysData.firstSupport
        && candleObj.close < candleObj.open
        && candleObj.open - candleObj.close > 10
        && candleObj.close - daysData.secondSupport < -5
        && daysData.belowFirstSupportCounter > 0 && daysData.firstSupportBrokenCounter > 0 && daysData.firstSupportBrokenCounter < daysData.belowFirstSupportCounter) {
        fnEnterShort(candleObj, 'fnBullOpenBreaksFirstSupport: The bull run ends and breaks the first support, which is days open, buying put option');
    }
}

function fnBearOpenBreaksFirstResistance(daysData, candleObj) {
    if (boolfnBearOpenBreaksFirstResistance === false) return;

    var daysData = arrdaysData[day];
    var candleObj = arrCandleObj[arrCandleObj.length - 1];
    if (daysData.OpenTrend === 'NEGATIVE' && candleObj.open > daysData.firstResistance && candleObj.close > daysData.firstResistance
        && daysData.firstResistanceBrokenCounter > 0 && daysData.aboveFirstResistanceCounter > 0
        && candleObj.close > candleObj.open
        && daysData.secondResistance - candleObj.close > 5
    ) {
        fnEnterLong(candleObj, 'fnBearOpenBreaksFirstResistance: The bear run ends and breaks the first resistance, which is days open, buying call option');
    }

}
function fnEnterShort(candleObj, strategy) {
    if (isTrading === false) {
        entry = candleObj.close;
        target = candleObj.close - TARGETTICK;
        stopLoss = candleObj.close + STOPLOSSTICK;
        isTrading = true;
        longShort = 1;
        entryPercentage = candleObj.percentageChange;
        console.log('%c%s %s', 'font-size:14px;font-weight:bold;background-color:black;color:white', candleObj.dtTime, "BUY PUT " + strategy);
        fnPrint('ENTRY', { strategy: strategy, position: 'Buy Put', entry: entry, target: target, stopLoss: stopLoss, dtTime: candleObj.dtTime, open: candleObj.open, high: candleObj.high, low: candleObj.low }, candleObj.IndiaVix)
        fnBuyPut();
    }
}
function fnEnterLong(candleObj, strategy) {
    if (isTrading === false) {
        entry = candleObj.close;
        target = candleObj.close + TARGETTICK
        stopLoss = candleObj.close - STOPLOSSTICK
        isTrading = true;
        longShort = 0;
        entryPercentage = candleObj.percentageChange;
        console.log('%c%s %s', 'font-size:14px;font-weight:bold;background-color:white;color:black', candleObj.dtTime, "BUY CALL " + strategy);
        fnPrint('ENTRY', { strategy: strategy, position: 'Buy Call', entry: entry, target: target, stopLoss: stopLoss, dtTime: candleObj.dtTime, open: candleObj.open, high: candleObj.high, low: candleObj.low }, candleObj.IndiaVix)
        fnBuyCall();
    }
}
function fnCheckCurrentDayBeforeEntry() {
    if (continueTradeOverride === true) return true;

    if (disableAfterTwoTrades === false) {
        return true;
    }

    var daysData = arrdaysData[day];
    if (daysData.hasProfited === true) {
        return false;
    }
    if (daysData.firstTrade === "NOTRADE") {
        return true;
    }
    if (daysData.firstTrade === "PROFIT") {
        console.log('%c Stopping further trades as first trade is in profit', 'background-color:lightblue;color:green;font-weight:bold');
        return false;
    }
    if (daysData.firstTrade !== "NOTRADE" && daysData.secondTrade === "NOTRADE") {
        return true;
    }
    if (daysData.firstTrade === "LOSS" && daysData.secondTrade === "LOSS") {
        console.log('%c Stopping further trades as both trades are loss', 'background-color:lightblue;color:red;font-weight:bold');
        return false;
    }
    if (daysData.firstTrade !== "NOTRADE" && daysData.secondTrade !== "NOTRADE") {
        return false;
    }

}

function fnEndPrint() {
    var plRatio = TARGETTICK / STOPLOSSTICK;
    var netPL = profitCounter - lossCounter;
    console.log('Profits: ', profitCounter, 'Loss: ', lossCounter, ' Profit/Loss Points: ', netPL);
    console.log('Profit Points Total: ', totalTradePointsProfit, ' Loss Points Total: ', totalTradePointsLoss, 'Net: ', totalTradePointsProfit - totalTradePointsLoss);

    var avgProfitPercent = (arrProfitPercent.reduce((a, b) => a + b, 0)) / arrProfitPercent.length;
    var avgLossPercent = (arrLossPercent.reduce((a, b) => a + b, 0)) / arrLossPercent.length;
    if (ALERTCLOSEOPENTRADES === false) {
        console.log('%c FAULT IN PROGRAM: OPEN TRADES WERE NOT CLOSED', 'background-color:red;color-white;font-size:20px');
    }
    if (ALERTTRADEWINDOWCLOSED === false) {
        console.log('%c FAULT IN PROGRAM: TRADE WINDOW CLOSED DID NOT TRIGGER', 'background-color:red;color-white;font-size:20px');
    }
    console.log('%c ****************************************************************************', 'color:red;font-size:25px;')
}

function fnProfit(dtTime, points) {
    var daysData = arrdaysData[day];
    daysData.hasProfited = true;
    if (daysData.firstTrade === "NOTRADE") {
        daysData.firstTrade = "PROFIT";
    }
    else {
        daysData.secondTrade = "PROFIT";
    }

    console.log('%c Profit, %s, Points Gained: %s', 'background-color:darkgreen;color:white', dtTime, points);


    profitCounter++;
    totalTradePointsProfit = totalTradePointsProfit + points;

    arrProfitPercent.push(entryPercentage);
    arrProfitRangePercent.push(entryNearRange);
    arrProfitDayRange.push(entryWhenAtRangeOf);
    arrProfitMin.push(entryMinute);
}
function fnLoss(dtTime, points) {
    console.log('%c Loss, %s, Points Lost: %s', 'background-color:darkred;color:white', dtTime, points);

    var daysData = arrdaysData[day];
    if (daysData.firstTrade === "NOTRADE") {
        daysData.firstTrade = "LOSS";
    }
    else {
        daysData.secondTrade = "LOSS";
    }
    totalTradePointsLoss = totalTradePointsLoss + points;
    lossCounter++;
    arrLossPercent.push(entryPercentage);
    arrLossRangePercent.push(entryNearRange);
    arrLossDayRange.push(entryWhenAtRangeOf);
    arrLossMin.push(entryMinute);

}

function fnPrint(scenario, obj, vix) {
    var printStmt;
    switch (scenario) {
        case 'ENTRY':
            console.log(obj.position, 'Vix:', vix, obj.dtTime, 'Entry:', obj.entry, 'Target:', obj.target, 'Stoploss:', obj.stopLoss, 'OHL:', obj.open, obj.high, obj.low);
            break;
        default:
            break;
    }

}
function fnPrintVerbose(msg) {
    console.log('%c %s', 'color:orange;', msg)
}

/**
    * ! If there is a GAP UP or a GAP DOWN of 1% - Enter Long or Enter Short respectively with trailing stoploss and target
    * 
   */
function fnSignificantGapDuringOpen() {
    if (boolfnSignificantGapDuringOpen === false)
        return;
    var daysData = arrdaysData[day];

    if (daysData.indx > 0) return;
    var candleObj = arrCandleObj[arrCandleObj.length - 1];

    if (daysData.previousClose < candleObj.open) {
        //Gap Up Opening.
        var gapPercent = ((candleObj.open - daysData.previousClose) / daysData.previousClose) * 100;
        if (gapPercent > 0.5
            //   && daysData.previousDayWas === "POSITIVE" && daysData.previousDayChangePercent > 1
        ) {
            if (daysData.previousClose < candleObj.close && candleObj.close > candleObj.open) {
                if (candleObj.IndiaVix < 20) {
                    fnPrintVerbose('Gap up opening and the VIX is below 20, Option writers will try to run for cover, BUY CALL');
                    fnEnterLong(candleObj, 'fnBullPatternAfterGapUp');
                }
                else if (candleObj.IndiaVix >= 20) {
                    fnPrintVerbose('Gap up opening and the VIX is above 20, profit booking will be seen, BUY PUT');
                    fnEnterShort(candleObj, 'fnBullPatternAfterGapUp');
                }
            }
            else {
                if (candleObj.IndiaVix < 20) {
                    fnPrintVerbose('Gap up opening and the VIX is below 20, HOWEVER, THE FIRST CANDLE IS RED!');
                    fnEnterShort(candleObj, 'fnBullPatternAfterGapUp');
                }
            }
        }
    }

    // if (daysData.previousClose > candleObj.open) {
    //     //Gap Down Opening.
    //     var gapPercent = ((daysData.previousClose - candleObj.open) / candleObj.open) * 100;
    //     if (gapPercent > 1) {
    //         fnEnterShort(candleObj, 'Gap Down Opening');
    //     }
    // }



}


